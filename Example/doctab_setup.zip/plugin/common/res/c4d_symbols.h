#ifndef C4D_SYMBOLS_H__
#define C4D_SYMBOLS_H__
enum
{
	//msg
	MSG_LOADFILE_FAIL
};
#endif C4D_SYMBOLS_H__

